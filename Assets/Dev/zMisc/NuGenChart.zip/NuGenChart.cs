﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI.Extensions;
using UnityEngine.UI;
#if UNITY_EDITOR
using UnityEditor;
#endif
[RequireComponent(typeof(RectTransform))]
[ExecuteInEditMode]
public class NuGenChart : MonoBehaviour
{
    [HideInInspector]
    [SerializeField]
    List<float> values;
    [Header("Y Axis")]
    public bool adjustToFitGraphY = true;
    [SerializeField]
    float _scaleY = 1;
    [SerializeField]
    float _offsetY = 0;
    public System.Action axisChanged;
    public float autoOffset = 0.1f;
    [SerializeField] [HideInInspector] UILineRenderer lineRenderer;
    [SerializeField] [HideInInspector] RectTransform rect;
    float _scaleYauto = 1;
    float _offsetYauto = 0;
    public float scaleY { get { return (adjustToFitGraphY ? _scaleYauto : _scaleY); } }
    public float offsetY { get { return (adjustToFitGraphY ? _offsetYauto : _offsetY); } }


    [Header("Stats")]
    [ReadOnly]
    public float minValue;
    [ReadOnly]
    public float maxValue;
    public int valueCount;
    int sampleSize;
    [Header("Range select")]
    public bool manualRange;
    [SerializeField]
    [Range(0, 1)]
    float _inPoint;
    [SerializeField]
    [Range(0, 1)]
    float _outPoint = 1;
    [SerializeField]
    [Range(-.04f, .04f)]
    float _scrub;
    [ReadOnly]
    [SerializeField]
    int outRangeSample;
    [Header("X Axis (Labels)")]
    public bool adjustToFitGraphX = true;
    public float xAxisStart;
    public float xAxisStep = 1f;
    [ReadOnly]
    [SerializeField]
    int inRangeSample;

    public Vector2 valueRangeX
    {
        get
        {
            float startVal = xAxisStart;
            float endVal = xAxisStart + xAxisStep * valueCount;
            float range = endVal - startVal;
            if (manualRange)
            {
                startVal = startVal + range * _inPoint;
                endVal = startVal + range * (_outPoint - _inPoint);
            }
            return new Vector2(startVal, endVal);
        }
    }
    public Vector2 valueRangeY
    {
        get
        {
            if (values.Count == 0) return new Vector2(1, 0);
            float d = scaleY - offsetY;
            if (d == 0) d = 1;
            return new Vector2(1 / d, -offsetY);
        }
    }
    public float inPoint
    {
        get { return (valueCount == 0 ? 0 : 1f * inRangeSample / valueCount); }
        set
        {
            if (adjustToFitGraphX) return;
            { _inPoint = value; inRangeSample = Mathf.FloorToInt(_inPoint * valueCount); }
            sampleSize = outRangeSample - inRangeSample;
        }
    }

    public float outPoint
    {
        get { return (valueCount == 0 ? 0 : 1f * outRangeSample / valueCount); }
        set
        {
            if (adjustToFitGraphX) return;
            _outPoint = value; outRangeSample = Mathf.FloorToInt(_outPoint * valueCount);
            sampleSize = outRangeSample - inRangeSample;
        }
    }

    public float scrub
    {
        set
        {
            _scrub = 0;
            if (value == 0) return;
            if ((_inPoint + value >= 0) && (_outPoint + value <= 1))
            {
                inPoint += value;
                outPoint += value;
            }
        }
    }

    float graphWidth { get { return rect.rect.width; } }
    float graphHeight { get { return rect.rect.height; } }
    void on()
    {
        Debug.Log("ss");
    }
    void Reset()
    {

        lineRenderer = GetComponentInChildren<UILineRenderer>();
        if (lineRenderer == null)
        {
            GameObject g = new GameObject("Graph");
#if UNITY_EDITOR
            Undo.RegisterCreatedObjectUndo(g, "Graph");
#endif
            g.transform.SetParent(transform);

            lineRenderer = g.AddComponent<UILineRenderer>();
            RectTransform graphRect = lineRenderer.GetComponent<RectTransform>();
            graphRect.anchorMin = Vector2.zero;
            graphRect.anchorMax = Vector2.zero;
            graphRect.pivot = Vector2.zero;
            graphRect.anchoredPosition = Vector3.zero;
            graphRect.transform.localScale = Vector3.one;
            graphRect.sizeDelta = new Vector2(1, 1);
        }
        values = new List<float>();
        rect = GetComponent<RectTransform>();
        if (rect.sizeDelta.x == 100 && rect.sizeDelta.y == 100) rect.sizeDelta = new Vector2(400, 300);
        GameObject labelsX = new GameObject("LabelsX");
        GameObject labelsY = new GameObject("LabelsY");
        labelsX.transform.SetParent(transform);
        labelsY.transform.SetParent(transform);
        NuGenChartLabels lX = labelsX.AddComponent<NuGenChartLabels>();
        NuGenChartLabels lY = labelsY.AddComponent<NuGenChartLabels>();

        labelsX.transform.localPosition = Vector2.zero;
        labelsY.transform.localPosition = Vector2.zero;

        lX.side = NuGenChartLabels.Side.left;
        lY.side = NuGenChartLabels.Side.bottom;
#if UNITY_EDITOR
        Undo.RegisterCreatedObjectUndo(labelsX, "GraphLabelsX");
        Undo.RegisterCreatedObjectUndo(labelsY, "GraphLabelsY");
#endif           
        clear();
        addValue(0);
        addValue(1);
        RepaintGraph(); ;
        name = "NuGenChart";
        Image i = gameObject.GetComponent<Image>();
        if (i == null) i = gameObject.AddComponent<Image>();
        if (i != null) i.color = new Color(0.1f, 0.1f, 0, 0.1f);

    }

    public void addValue(float f)
    {
        if (values == null) clear();
        values.Add(f);
        valueCount++;
        if (followNewValues || outRangeSample == valueCount)
            outRangeSample++;
        if (followNewValues && inRangeSample > 0) inRangeSample++;
        if (f > maxValue) maxValue = f;
        if (f < minValue) minValue = f;
    }
    void Start()
    {
        lineRenderer = GetComponentInChildren<UILineRenderer>();
    }
    void OnValidate()
    {
        if (_scaleY < 0) _scaleY = -_scaleY;
        if (adjustToFitGraphX)
        {
            _inPoint = 0;
            _outPoint = 1;
        }
        else
        {
            if (_inPoint > _outPoint) _inPoint = 0;
            if (followNewValues && inRangeSample == 0 && outRangeSample > 10) inRangeSample = 1;
            if (manualRange)
            {
                inPoint = _inPoint;
                outPoint = _outPoint;
            }
            scrub = _scrub;
        }
        RepaintGraph();
    }
    float scaledValue(float f)
    {
        return (f) * scaleY + offsetY;
    }

    Vector2[] GetPointsInRange()
    {
        if (outRangeSample - inRangeSample < 1) return new Vector2[0];
        minValue = System.Single.MaxValue;
        maxValue = System.Single.MinValue;
        int lastIndex = outRangeSample;
        if (lastIndex >= values.Count) lastIndex = values.Count - 1;
        for (int i = inRangeSample; i < outRangeSample; i++)
        {
            float thisValue = values[i];
            if (thisValue > maxValue) maxValue = thisValue;
            if (thisValue < minValue) minValue = thisValue;
        }
        if (maxValue == minValue) _scaleYauto = 1;
        else
            _scaleYauto = 1 / (maxValue - minValue) * (1 - 2 * autoOffset);
        _offsetYauto = -minValue * _scaleYauto + autoOffset;
        int range = outRangeSample - inRangeSample;
        Vector2[] points = new Vector2[range];
        float xSCale = graphWidth / ((range == 1) ? 1 : range - 1);
        float h = graphHeight;
        if (range > values.Count - inRangeSample) range = values.Count - inRangeSample;
        for (int i = 0; i < range; i++)
            points[i] = new Vector2(i * xSCale, scaledValue(values[inRangeSample + i]) * h);
        return points;
    }
    //public Vector2[] test;
    [ExposeMethodInEditor]
    void RepaintGraph()
    {
        if (lineRenderer == null) return;
        lineRenderer.Points = GetPointsInRange();
        lineRenderer.SetVerticesDirty();
        if (axisChanged != null) axisChanged.Invoke();
    }

    [ExposeMethodInEditor]
    void clear()
    {
        values = new List<float>();
        valueCount = 0;
        outRangeSample = 0;
        minValue = 0;
        maxValue = 1;
        //   OnValidate();
    }
    [ExposeMethodInEditor]
    void addRandomData50()
    {
        for (int i = 0; i < 50; i++)
            addValue(Random.value);
        RepaintGraph();
    }
    public bool followNewValues = true;
    [Header("Debug")]
    [Range(-1, 2)]
    public float dataToAdd;
    [ExposeMethodInEditor]
    void AddSampleData()
    {
        addValue(dataToAdd);
        OnValidate();
    }
    void Update()
    {
        if (transform.hasChanged)
        {
            RepaintGraph();
            transform.hasChanged = false;
        }
    }
}



#if UNITY_EDITOR

public static class NuChartMenu // stolen from smrt chart
{

        [MenuItem("GameObject/UI/NuGenChart")]
        public static void CreateChart(MenuCommand menuCommand)
        {
            GameObject parent = menuCommand.context as GameObject;
            if (parent == null || parent.GetComponentInParent<Canvas>() == null)
            {
                GameObject canvas=GameObject.FindObjectOfType(typeof(Canvas)) as GameObject;
                 if (canvas==null) 
                 { canvas = new GameObject("Canvas", typeof(Canvas));
                    canvas.GetComponent<Canvas>().renderMode = RenderMode.ScreenSpaceOverlay;
                    canvas.AddComponent<CanvasScaler>();
                    canvas.AddComponent<GraphicRaycaster>();
                 }
                parent = canvas;
                //return;
            }
            GameObject chart = new GameObject("NuGenChart");
            Undo.RegisterCreatedObjectUndo(chart, "create chart");
            Undo.SetTransformParent(chart.transform, parent.transform, "parent " + chart.name);
            GameObjectUtility.SetParentAndAlign(chart, parent);
            
            chart.AddComponent<NuGenChart>();
            Selection.activeGameObject=chart;
        }

}
#endif