﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
#if UNITY_EDITOR
using UnityEditor;
#endif
[ExecuteInEditMode]
[RequireComponent(typeof(RectTransform))]
public class NuGenChartLabels : MonoBehaviour
{
    [SerializeField]
    Side _side;
    public enum Side { left, right, top, bottom }
    public enum DigitPrecision { full, integer, one, two, three, expotential }
    public DigitPrecision precision;
    public float size = 100;
    public float distance = 10;
    public Text templateText;
    public int labelCount = 10;
    [SerializeField]
    NuGenChart nuGenChart;
    List<Text> texts;
    [SerializeField] [HideInInspector] RectTransform rect;
    void Reset()
    {
        nuGenChart = GetComponentInParent<NuGenChart>();
        if (nuGenChart == null) 
        {
            Debug.Log("No Chart in parent");
             DestroyImmediate(this);
        }
        texts = new List<Text>();
        if (rect == null) rect = GetComponent<RectTransform>();
        templateText = GetComponentInChildren<Text>();
        if (templateText == null)
        {
            GameObject game = new GameObject("Label");
            game.transform.SetParent(transform);
            game.transform.localScale = Vector3.one;
            templateText = game.AddComponent<Text>();
            templateText.text = "x";
            templateText.alignment = TextAnchor.MiddleCenter;
        }
        templateText.name = "label template";
		templateText.raycastTarget=false;
        texts.Add(templateText);
    }

    public Side side
    {
        get { return _side; }
        set
        {
            _side = value;
#if UNITY_EDITOR
            if (isHorizontal)
                EditorApplication.delayCall += setGroupHorizontal;
            else
                EditorApplication.delayCall += setGroupVertical;
#endif
            if (rect == null) rect = GetComponent<RectTransform>();
            rect.localScale = Vector3.one;

            switch (value)
            {
                case Side.left:
                    rect.pivot = new Vector2(1, 0.5f);
                    rect.anchorMin = new Vector2(0, 0);
                    rect.anchorMax = new Vector2(0, 1);
                    rect.sizeDelta = new Vector2(size, 0);
                    rect.anchoredPosition = new Vector2(-distance, 0);
                    break;
                case Side.right:
                    rect.pivot = new Vector2(0, 0.5f);
                    rect.anchorMin = new Vector2(1, 0);
                    rect.anchorMax = new Vector2(1, 1);
                    rect.sizeDelta = new Vector2(size, 0);
                    rect.anchoredPosition = new Vector2(+distance, 0);
                    break;
                case Side.top:

                    rect.pivot = new Vector2(0.5f, 0f);
                    rect.anchorMin = new Vector2(0, 1);
                    rect.anchorMax = new Vector2(1, 1);
                    rect.sizeDelta = new Vector2(0, size);
                    rect.anchoredPosition = new Vector2(-0, distance);
                    break;
                case Side.bottom:
                    rect.pivot = new Vector2(0.5f, 1f);
                    rect.anchorMin = new Vector2(0, 0);
                    rect.anchorMax = new Vector2(1, 0);
                    rect.sizeDelta = new Vector2(0, size);
                    rect.anchoredPosition = new Vector2(0,- distance);
                    break;
            }

#if UNITY_EDITOR
            EditorApplication.delayCall += createLabels;
#endif
        }
    }

    void setGroupHorizontal()
    {
        VerticalLayoutGroup vg = GetComponent<VerticalLayoutGroup>();
        if (vg != null) DestroyImmediate(vg);
        HorizontalLayoutGroup hg = GetComponent<HorizontalLayoutGroup>();
        if (hg == null) hg = gameObject.AddComponent<HorizontalLayoutGroup>();
        hg.childAlignment = (side == Side.top ? TextAnchor.LowerCenter : TextAnchor.UpperCenter);
        hg.childControlHeight = true;
        hg.childControlWidth = true;
        int padding = -(int)(rect.rect.width / labelCount / 2);
        hg.padding.left = padding;
        hg.padding.right = padding;
    }

    void setGroupVertical()
    {
        HorizontalLayoutGroup hg = GetComponent<HorizontalLayoutGroup>();
        if (hg != null) DestroyImmediate(hg);
        VerticalLayoutGroup vg = GetComponent<VerticalLayoutGroup>();
        if (vg == null) vg = gameObject.AddComponent<VerticalLayoutGroup>();
        vg.childAlignment = (side == Side.left ? TextAnchor.MiddleRight : TextAnchor.MiddleLeft);
        vg.childControlHeight = true;
        vg.childControlWidth = true;
        int padding = -(int)(rect.rect.height / labelCount / 2);
        vg.padding.top = padding;
        vg.padding.bottom = padding;
    }
TextAnchor GetAnchor()
{
	if (side==Side.top) return TextAnchor.LowerCenter;
	if (side==Side.right) return TextAnchor.MiddleLeft;
	if (side==Side.left) return TextAnchor.MiddleRight;
	return TextAnchor.UpperCenter;
}
    void destroyLabels()
    {
        int childCount = transform.childCount;
        for (int i = 1; i < childCount; i++)
            DestroyImmediate(transform.GetChild(1).gameObject);
    }
    void createLabels()
    {
        texts = new List<Text>();
        texts.Add(templateText);
        destroyLabels();
		templateText.alignment = GetAnchor();
        for (int i = 1; i < labelCount; i++)
        {
            GameObject l = Instantiate(templateText.gameObject, transform);
            l.name = "label_" + i;
            texts.Add(l.GetComponent<Text>());
        }
        FillValues();
    }
    void OnEnable()
    {
		Reset();
        if (nuGenChart == null) nuGenChart = GetComponentInParent<NuGenChart>();
        if (nuGenChart == null) { Debug.LogWarning("No DATA"); return; } else
        nuGenChart.axisChanged += FillValues;
    }
    void OnDisable()
    {
        if (nuGenChart!=null)
        nuGenChart.axisChanged -= FillValues;
    }
    bool isHorizontal { get { return (side == Side.top || side == Side.bottom); } }
    string formatString
    {
        get
        {
            switch (precision)
            {
                case DigitPrecision.integer: return "0";
                case DigitPrecision.one: return "0.0";
                case DigitPrecision.two: return "0.00";
                case DigitPrecision.three: return "0.000";
                case DigitPrecision.expotential: return "e";
            }
            return null;
        }
    }

    [ExposeMethodInEditor]
    void FillValues()
    {
        if (nuGenChart == null) return;
        Vector2 minmax = (isHorizontal ? nuGenChart.valueRangeX : nuGenChart.valueRangeY);
        float step = (minmax.y - minmax.x) / labelCount;
        if (texts!=null)
        for (int i = 0; i < texts.Count; i++)
        {
            if (texts[i]!=null)
            texts[i].text = (minmax.x + step * i).ToString(formatString); ;
        }
    }

    void recreate()
    {
#if UNITY_EDITOR
        EditorApplication.delayCall += createLabels;
#endif
    }

    protected virtual void OnValidate()
    {
        if (labelCount < 1) labelCount = 1;
        side = _side;
   //     recreate();
        FillValues();
    }

}
